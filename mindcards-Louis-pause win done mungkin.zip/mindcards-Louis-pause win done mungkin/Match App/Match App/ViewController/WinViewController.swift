//
//  WinViewController.swift
//  Match App
//
//  Created by Louis  Valen on 26/04/19.
//  Copyright © 2019 Tommy Rachmat. All rights reserved.
//

import UIKit

class WinViewController: UIViewController {
    @IBOutlet weak var labelBestTime: UILabel!
    
    @IBOutlet weak var labelName: UILabel!
    
    var name = ""
    var time = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        labelName.text = name
        labelBestTime.text = time
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
