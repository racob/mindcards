//
//  PauseViewController.swift
//  Match App
//
//  Created by Louis  Valen on 25/04/19.
//  Copyright © 2019 Tommy Rachmat. All rights reserved.
//

import UIKit

class PauseViewController: UIViewController {

    @IBOutlet weak var rUsure: UIView!
    var onreturn: (()->())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        rUsure.isHidden = true
    }
    
    @IBAction func ReturnClosePopup(_ sender: Any) {
        if let onreturn = onreturn {
            onreturn()
        }
        self.view.removeFromSuperview()
    }
    
    @IBAction func ButtonNO(_ sender: Any) {
         rUsure.isHidden = true
    }
    @IBAction func buttonExit(_ sender: Any) {
        rUsure.isHidden = false
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
